// Runs on Instacart-powered stores: Publix (instacart.com) and Restaurant Depot
// (member.restaurantdepot.com). It adds items ONE AT A TIME across page loads.
//
// The reliable way to add the RIGHT product is an exact product URL. On a product
// page the MAIN product's button reads exactly "Add to cart" — every other "Add"
// button on the page ("Add 1 ct <name>") belongs to a RELATED/carousel item and
// must be ignored. We click only the main "Add to cart" button, so we can never
// add the wrong item. If a line has no URL we fall back to search (top result).
//
// Quantity: after adding, Instacart shows a compact "N in cart" control whose
// stepper is a hover/portal widget that is unreliable to script. We add the item
// (qty 1, correct product guaranteed) and then make a BEST-EFFORT attempt to raise
// the quantity. Getting the right item is the priority; qty can be nudged by hand.
(function () {
  const isInstacart = location.host.includes('instacart.com');
  const STORE_KEY = isInstacart ? 'order_instacart' : 'order_rd';
  const RUN_KEY = 'run_' + STORE_KEY;
  const LABEL = isInstacart ? 'Publix' : 'Restaurant Depot';
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  // Base path for search URLs. On /store/<slug>/... use that; on a /products page
  // with ?retailerSlug=publix derive it from the query param.
  function storeBase() {
    const m = location.pathname.match(/^(\/store\/[^/]+)/);
    if (m) return m[1];
    const rs = new URLSearchParams(location.search).get('retailerSlug');
    if (rs) return '/store/' + rs;
    return '';
  }

  const isProduct = () => /\/products\//.test(location.pathname);
  const isSearch = () => /\/s(\/|$)/.test(location.pathname) || location.search.includes('k=');
  const buttons = () => [...document.querySelectorAll('button')];
  const norm = (b) => (b.getAttribute('aria-label') || b.innerText || '').trim();

  // The main product's add button: text/aria is EXACTLY "Add to cart".
  const mainAddBtn = () => buttons().find((b) => /^add to cart$/i.test(norm(b)));
  // Already-in-cart indicator on the main product ("1 in cart", "2 in cart"...).
  const inCartBtn = () => buttons().find((b) => /\b\d+\s+in cart\b/i.test((b.innerText || '')));
  // Search-result / RD fallback: the first "Add" button on a results page.
  const firstResultAdd = () => buttons().find((b) => /^add\b/i.test((b.getAttribute('aria-label') || b.innerText || '').trim()));
  // Any quantity-increment control (used best-effort).
  const anyIncBtn = () => buttons().find((b) => {
    const a = (b.getAttribute('aria-label') || '').toLowerCase();
    const t = (b.innerText || '').trim();
    return /increment unit quantity|increase quantity/.test(a) || t === '+';
  });

  const searchUrl = (q) => storeBase() + '/s?k=' + encodeURIComponent(q);
  // Where to send the browser for a line: exact product URL if provided, else search.
  const target = (line) => {
    if (line.url) {
      if (line.url.startsWith('http')) return line.url;      // full URL (preferred)
      if (line.url.startsWith('/')) return line.url;          // absolute path
      return storeBase() + '/products/' + line.url;           // bare product id
    }
    return searchUrl(line.name);
  };

  const setBanner = (t) => { const b = document.getElementById('colette-fill-btn'); if (b) b.textContent = t; };
  const getRun = async () => (await chrome.storage.local.get(RUN_KEY))[RUN_KEY];
  const saveRun = (r) => chrome.storage.local.set({ [RUN_KEY]: r });

  // Best-effort quantity bump. Never throws; if it can't find a stepper it leaves
  // the item at qty 1 (correct item is already in the cart).
  async function bumpQty(qty) {
    const want = (qty || 1) - 1;
    for (let k = 0; k < want; k++) {
      // Open the compact stepper if it's collapsed to "N in cart".
      const ic = inCartBtn();
      if (ic) { ic.click(); await sleep(500); }
      const plus = anyIncBtn();
      if (!plus) break;
      plus.click();
      await sleep(700);
    }
  }

  // Add the main product on the current product page. Returns true if added or
  // already present. NEVER clicks a carousel "Add 1 ct <name>" button.
  async function addMainProduct(line) {
    const add = mainAddBtn();
    if (add) { add.click(); await sleep(1500); await bumpQty(line.qty); return true; }
    if (inCartBtn()) { await bumpQty(line.qty); return true; } // already in cart
    return false;
  }

  async function advance(run) {
    run.i++;
    if (run.i >= run.lines.length) {
      run.active = false; await saveRun(run); setBanner('✓ Done — review cart');
      const missed = (run.missed || []);
      alert(`Colette: added ${run.lines.length - missed.length}/${run.lines.length} items to ${LABEL}. Review your cart.` +
        (missed.length ? `\n\nNot found: ${missed.join(', ')}` : ''));
      return;
    }
    await saveRun(run);
    location.href = target(run.lines[run.i]);
  }

  async function resume() {
    const run = await getRun();
    if (!run || !run.active) return;
    const line = run.lines[run.i];
    setBanner(`Adding ${run.i + 1}/${run.lines.length}: ${line.name || 'item'}`);

    if (line.url) {
      // Exact product URL — add the main product here (right item guaranteed).
      await sleep(2600);
      const ok = await addMainProduct(line);
      if (!ok) (run.missed = run.missed || []).push(line.name || line.url);
      await advance(run);
    } else if (isSearch() && !isProduct()) {
      // Search fallback (no URL): add the top result.
      await sleep(2600);
      const add = firstResultAdd();
      if (!add) { (run.missed = run.missed || []).push(line.name); return advance(run); }
      add.click();
      await sleep(1600);
      if (!isProduct()) { await bumpQty(line.qty); await advance(run); }
      // (RD navigates to the product page on Add → handled by the branch below.)
    } else if (isProduct()) {
      // Arrived at a product page from a search result (RD). Ensure it's added.
      await sleep(1600);
      await addMainProduct(line);
      await advance(run);
    }
  }

  async function start() {
    const o = (await chrome.storage.local.get(STORE_KEY))[STORE_KEY];
    if (!o || !o.lines || !o.lines.length) {
      alert(`No Colette ${LABEL} order found.\n\nOpen the Colette supplier sheet, set quantities, click "Send to ${LABEL}", then press this button.`);
      return;
    }
    await saveRun({ active: true, i: 0, lines: o.lines, missed: [] });
    location.href = target(o.lines[0]);
  }

  function addButton() {
    if (document.getElementById('colette-fill-btn')) return;
    const b = document.createElement('button');
    b.id = 'colette-fill-btn';
    b.textContent = `🥖 Fill ${LABEL} cart from Colette`;
    Object.assign(b.style, {
      position: 'fixed', top: '12px', left: '50%', transform: 'translateX(-50%)', zIndex: 999999,
      background: '#c99a3b', color: '#1a1206', border: '2px solid #1a1206', borderRadius: '22px',
      padding: '12px 18px', fontWeight: '700', cursor: 'pointer', fontFamily: 'sans-serif',
      boxShadow: '0 3px 14px rgba(0,0,0,.35)',
    });
    b.addEventListener('click', start);
    document.body.appendChild(b);
  }

  new MutationObserver(addButton).observe(document.documentElement, { childList: true, subtree: true });
  addButton();
  resume();
})();
