// Runs on the Colette supplier order sheet. Bridges the chosen order into the
// extension's storage so the Costco page can read it and fill the cart.
window.addEventListener('colette-send', (e) => {
  try {
    const { supplier, lines } = (e && e.detail) || {};
    if (!supplier || !Array.isArray(lines)) return;
    chrome.storage.local.set({ ['order_' + supplier]: { lines, at: Date.now() } }, () => {
      window.dispatchEvent(new CustomEvent('colette-saved', { detail: { supplier, count: lines.length } }));
    });
  } catch (err) { console.warn('Colette extension save failed', err); }
});
// Let the page know the extension is installed (so it can show the 1-click button).
window.dispatchEvent(new CustomEvent('colette-ext-ready'));
