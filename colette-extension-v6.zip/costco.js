// Runs on Costco Business Center's "Order by Item Number" page. Adds a floating
// button that fills every item # + quantity from the Colette order and adds to cart.
(function () {
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const setVal = (el, v) => {
    const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
    setter.call(el, String(v));
    ['input', 'change', 'keyup', 'blur'].forEach((t) => el.dispatchEvent(new Event(t, { bubbles: true })));
  };

  function addButton() {
    if (document.getElementById('colette-fill-btn')) return;
    const b = document.createElement('button');
    b.id = 'colette-fill-btn';
    b.textContent = '🥐 Fill Costco cart from Colette';
    Object.assign(b.style, {
      position: 'fixed', top: '12px', left: '50%', transform: 'translateX(-50%)', zIndex: 999999,
      background: '#c99a3b', color: '#1a1206', border: 'none', borderRadius: '22px',
      padding: '12px 18px', fontWeight: '700', cursor: 'pointer', fontFamily: 'sans-serif',
      boxShadow: '0 2px 12px rgba(0,0,0,.25)',
    });
    b.addEventListener('click', run);
    document.body.appendChild(b);
  }

  async function run() {
    const b = document.getElementById('colette-fill-btn');
    chrome.storage.local.get('order_costco', async (d) => {
      const o = d && d.order_costco;
      if (!o || !o.lines || !o.lines.length) {
        alert('No Colette order found.\n\nOpen the Colette supplier sheet, set your Costco quantities, and click "Send to Costco" — then come back here and press this button.');
        return;
      }
      b.disabled = true;
      let done = 0;
      for (const l of o.lines) {
        if (!l.id) continue;
        let item = [...document.querySelectorAll('input.item-number-textbox')].find((i) => !i.value.trim());
        if (!item) item = [...document.querySelectorAll('input.item-number-textbox')].pop();
        if (!item) break;
        setVal(item, l.id);
        const row = item.closest('tr') || item.closest('.row') || item.parentElement.parentElement;
        const qty = row && row.querySelector('input.qty-textbox');
        if (qty) setVal(qty, l.qty);
        // Nudge Costco to validate the item and add a fresh row.
        item.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', keyCode: 13, bubbles: true }));
        item.dispatchEvent(new KeyboardEvent('keyup', { key: 'Enter', keyCode: 13, bubbles: true }));
        item.blur();
        done++;
        b.textContent = `Filling… ${done}/${o.lines.length}`;
        await sleep(1700);
      }
      b.textContent = 'Adding to cart…';
      const add = document.querySelector('#obiAddToCart');
      if (add) add.click();
      await sleep(1500);
      b.textContent = '✓ Done — review your cart';
      b.disabled = false;
    });
  }

  // The page renders rows dynamically; keep the button present.
  new MutationObserver(addButton).observe(document.documentElement, { childList: true, subtree: true });
  addButton();
})();
